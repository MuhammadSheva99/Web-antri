#Aplikasi Antrian
Aplikasi sangat sederhana yang dibuat untuk proses antrian di dimanapun terutama di bank.
Ada 3 interface yaitu :
* Client
![Client](assert/img/client.png)
* Monitoring
![Monitoring](assert/img/monitoring.png)
* Admin
![Admin](assert/img/admin.png)

## Requirement
* XAMPP(Apache dan MySQL)
* PHP
* HTML dan CSS
* Bootstrap CSS
* Jquery