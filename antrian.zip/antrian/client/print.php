<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<script>window.print</script>
</body>
</html>